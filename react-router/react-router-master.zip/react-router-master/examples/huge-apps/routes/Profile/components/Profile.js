import React, { Component } from 'react'

class Profile extends Component {
  render() {
    return (
      <div>
        <h2>Profile</h2>
      </div>
    )
  }
}

module.exports = Profile
