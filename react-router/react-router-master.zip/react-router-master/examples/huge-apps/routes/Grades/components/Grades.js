import React from 'react'

class Grades extends React.Component {

  render() {
    return (
      <div>
        <h2>Grades</h2>
      </div>
    )
  }

}

module.exports = Grades
